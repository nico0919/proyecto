/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

window.addEventListener('load', function () {
    document.getElementById('btnRegistrar').addEventListener('click', function(){
       var contraseña = document.getElementById('txtPassword').value;
       var confContraseña = document.getElementById('txtRepetirPassword').value;
       
       
        if (confContraseña!= contraseña ) {
           alert('Las Contraseñas deben coincidir');
            
        }
  
            
       
    });
});
    

    /*
    document.getElementById('btnRegistrar').addEventListener('click', function(){
        
        var contraseña = document.getElementById('txtPassword').value;
        var confContraseña = document.getElementById('txtRepetirPassword').value;
       
        var bandera = false;
        
        if (contraseña.equals(confContraseña) ) {
            bandera = true;
        }
        
        if(bandera){
            document.getElementById('formRegistro').submit();
        }else{
            alert('Las Contraseñas deben coincidir');
             
        }
    });
    
});
*/
