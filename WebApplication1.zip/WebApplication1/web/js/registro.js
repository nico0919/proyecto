/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

window.addEventListener('load', function () {
    document.getElementById('btnRegistrar').addEventListener('click', function(){
        var tipo = document.getElementById('txtTipo').value;
        var nombre = document.getElementById('txtUsuario').value;
        var contraseña = document.getElementById('txtPassword').value;
        var confContraseña = document.getElementById('txtRepetirPassword').value;
        var nombres = document.getElementById('txtNombre').value;
        var correo = document.getElementById('txtCorreo').value;
        
        var bandera = false;
        
        if (tipo.length > 0 && nombre.length > 0 && contraseña.length > 0 && confContraseña.length > 0 && nombres.length > 0 && correo.length > 0) {
            bandera = true;
        }
        
        if(bandera){
            document.getElementById('formRegistro').submit();
        }else{
            alert('Por favor complete la informacion');
             
        }
    });
    
});


    