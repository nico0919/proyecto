/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author FAMILIA
 */
public class Conexion {
    
    private String userName = "equipodev";
    private String password = "904oXp#o";
    private String host = "198.71.227.97";
    private String port = "3306";
    private String database= "pseudosaga";
    private String classname = "com.mysql.jdbc.Driver";
    private String url = "jdbc:mysql://"+host+":"+port+"/"+database;
    private Connection con;
    
    
  //  private  String base = "pseudosaga";//usuarios
  //  private  String user = "equipodev";//root
  //  private  String password = "904oXp#o";//remoto: 904oXp#o
    //private  String url = "jdbc:mysql://198.71.227.97:3306/" + base;//198.71.227.97
    //private Connection conn = null;
 
   
    public Conexion(){
        try {
            Class.forName(classname);
            con = DriverManager.getConnection(url,userName,password);
        } catch (ClassNotFoundException ex) {
            System.err.println("Error" + ex) ;
            
            
        } catch (SQLException e){
            System.err.println("Error" + e);
        }
    }
    
    public Connection getConnection(){
        
        return  con;
        
    }
     
    
   
    
   /* public Connection getConexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver")  ;
            conn = DriverManager.getConnection(url, user, password);
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        } catch } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
     (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return conn;
         
    }
 
    public void desconectar(){
        conn = null;
        if (conn == null) {
            System.out.println("Conection Ended");
        }
    }
*/

    
}
