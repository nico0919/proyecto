/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Realizar insersiones y consultas a la base de Datos. 
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.rngom.digested.Main;

/**
 *
 * @author FAMILIA
 */
public class SQLUsuarios extends Conexion {

    //Insersiones
    
    public boolean registrar(String usuario, String password, String nombre, String correo, String tipo){
        
        PreparedStatement pst = null;
        
        try {
            String consulta = "Insert into usuario(usuario, password, nombre, correo, id_tipo) values(?,?,?,?,?) ";
            pst = getConnection().prepareStatement(consulta);
          
            pst.setString(1, usuario);
            pst.setString(2, password);
            pst.setString(3, nombre);
            pst.setString(4, correo);
            pst.setString(5, tipo);
     
            if (pst.executeUpdate() == 1) 
                return true;
            
            
        } catch (Exception ex) {
             System.err.println("Error" + ex);
        }finally{
            try {
                if(getConnection()!= null) getConnection().close(); 
                if(pst != null) pst.close();
            } catch (Exception e) {
                System.err.println("Error" + e);
            }
                
            
        }
        
        
        return false;
    }

    
  /*  public boolean registrar(Usuarios usr) {

        //Preparar la consulta
        PreparedStatement ps = null;
        Connection con = getConnection();

        //Variable sql para consulta de datos.
        String sql = "INSERT INTO usuario (usuario, password, nombre, correo, id_tipo) VALUES(?,?,?,?,?)";

        try {
            //Preparar Consulta
            ps = con.prepareStatement(sql);

            //Conexion entre el modelo para insertarlo a la base de datos. 
            ps.setString(1, usr.getUsuario());
            ps.setString(2, usr.getPassword());
            ps.setString(3, usr.getNombre());
            ps.setString(4, usr.getCorreo());
            ps.setInt(5, usr.getIdTipo());

            //Ejecutar la insersion.
            ps.execute();

            return true;

        } catch (SQLException ex) {
            Logger.getLogger(SQLUsuarios.class.getName()).log(Level.SEVERE, null, ex);

            return false;
        }
    }*/

//    Valida si el usuario ya existe
 /*   public int existeUsuario(String usr) {

        //Preparar la consulta
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConnection();

        //Variable sql para consulta de datos.
        String sql = "SELECT count(id) FROM usuario WHERE usuario = ?";

        try {
            //Preparar Consulta
            ps = con.prepareStatement(sql);

            //Verifica Usuario
            ps.setString(1, usr);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

            return 1;

        } catch (SQLException ex) {
            Logger.getLogger(SQLUsuarios.class.getName()).log(Level.SEVERE, null, ex);

            return 1;
        }
    }*/

    public boolean loginJSP(String usuario, String contraseña, String tipoUsuario) {
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            String consulta = "SELECT * FROM usuario WHERE usuario = ? and password = ? and id_tipo = ?";
            pst = getConnection().prepareStatement(consulta);

            pst.setString(1, usuario);
            pst.setString(2, contraseña);
            pst.setString(3, tipoUsuario);

            rs = pst.executeQuery();
            if (rs.absolute(1)) {
                return true;

            }

        } catch (Exception e) {
            System.err.println("Error" + e);
        } finally {
            try {

                if (getConnection() != null) 
                    getConnection().close();
                
                if (pst != null) 
                    pst.close();
                
                if (rs != null) 
                    rs.close();
                

            } catch (Exception e) {
                            System.err.println("Error" + e);

            }

        }

        return false;
    }

 /*   public boolean login(Usuarios usr) {

        //Preparar la consulta
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        //Variable sql para consulta de datos.
        String sql = "SELECT id, usuario, password, nombre, id_Tipo FROM usuario WHERE usuario = ?";

        try {
            //Preparar Consulta
            ps = con.prepareStatement(sql);

            //Verifica Usuario
            ps.setString(1, usr.getUsuario());
            rs = ps.executeQuery();

            if (rs.next()) {
                if (usr.getPassword().equals(rs.getString(3))) {
                    usr.setId(rs.getInt(1));
                    usr.setNombre(rs.getString(4));
                    usr.setIdTipo(rs.getInt(5));

                    return true;
                } else {
                    return false;
                }
            }

            return false;

        } catch (SQLException ex) {
            Logger.getLogger(SQLUsuarios.class.getName()).log(Level.SEVERE, null, ex);

            return false;
        }
    }
*/

/*    public boolean esEmail(String correo) {

        // Patrón para validar el email
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

        Matcher mather = pattern.matcher(correo);

        return mather.find();

    }*/
  /*  
    
   public static void main(String[] args){
        
        SQLUsuarios co = new SQLUsuarios();
        System.out.println(co.registrar("falcao1", "1234", "falcao garcia", "fc9@hotmail.com"));
    }
*/
   /* public static void main(String[] args){
        
        SQLUsuarios co = new SQLUsuarios();
        System.out.println(co.loginJSP("hol", "hola"));
    }*/
    
}
